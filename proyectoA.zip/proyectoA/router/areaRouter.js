//se crean las sub_rutas para area
const express = require (`express`);
const area = express.Router();

area.get("/area",(req,res)=>{
  res.send ("hola estoy en el get de area");  
});

area.post("/area",(req,res)=>{
    res.send ("hola estoy en el post de area");
});

area.put("/area",(req,res)=>{
    res.send ("hola estoy en el put de area");
});

area.delete("/area",(req,res)=>{
    res.send ("hola estoy en el delete de area");
});



//see xporta la ruta empresa
module.exports = area;