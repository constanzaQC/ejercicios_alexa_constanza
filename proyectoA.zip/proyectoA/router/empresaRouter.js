//se crean las sub_rutas para empresa
const express = require (`express`);
const empresa = express.Router();

empresa.get("/empresa",(req,res)=>{
    res.send("hola estoy en el get de empresa");
});

empresa.post ("/empresa",(req,res)=>{
    res.send("hola estoy en el post de empres");
});

empresa.put ("/empresa",(req,res)=>{
    res.send ("hola estoy en el put de empresa");
});

empresa.delete ("/empresa",(req,res)=>{
    res.send ("hola estoy en el delete de empresa");
});


//se exporta la ruta empresa
module.exports = empresa;