// se crean las sub_rutas para empleado
const express = require (`express`);
const empleado = express.Router();

empleado.get ("/empleado", (req,res)=>{
    res.send ("hola estoy en el get de empleado");
});

empleado.post ("/empleado",(req,res)=>{
    res.send ("hola estoy en el post de empleado");

});

empleado.put ("/empleado", (req,res)=>{
    res.send ("hola estoy en el put de empleado");
});

empleado.delete ("/empleado", (req,res)=>{
    res.send ("hola estoy en el delete de empleado");
});


//se exporta la ruta empleado
module.exports = empleado;
