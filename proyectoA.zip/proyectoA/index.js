//se hace el archivo de ejecucion
const express=require("express");
const app = express();
let areaRouter=require("./router/areaRouter");
let empleadoRouter=require("./router/empleadoRouter");
let empresaRouter=require("./router/empresaRouter");
//mildaware
app.use("/constanza",areaRouter)
app.use("/constanza",empleadoRouter)
app.use("/constanza",empresaRouter)

//ruta

app.get("/constanza", (req,res)=>{
    res.send("soy una vaca");
});

//se hace la configuracion del servidor
const PORT = 5000;
app.listen(PORT,() => {
    console.log(`servidor corriendo en el puerto: ${PORT}`);        
})

